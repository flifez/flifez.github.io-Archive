---
author: FlifeX, MMXXXVIII
categories: cool_things
date: "2021-02-14T02:21:04Z"
title: How to simulate smoke with MantaFlow in Blender 2.9
---

- Estimated Reading Time: **15-20min**
<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="//music.163.com/outchain/player?type=2&id=444058919&auto=1&height=66"></iframe>

###  Introduction

![final](https://ftp.bmp.ovh/imgs/2021/02/14828e06d0c47839.png)

*Example Final Output*

You need to install **Blender** (in this tutorial, my version is **2.91.0**), and it is better if you have some basic Blender knowledge.

### Smoke
- Create a default cube. 

- Then, apply **<u>O</u>bject - <u>Q</u>uick Effects - Quick <u>S</u>moke** to the cube. 

If everything goes well, you will see a cube consists of wireframes (**Smoke Domain**) and another smaller cube in it. If we observe it carefully, we can find that a smaller cube is attached to one corner of the smoke domain, which represents the **resolution of smoke to be baked** (we will talk about that later).

- Adjust the smoke in the **smoke domain**'s *Physics Properties* tab. Here, I will provide a group of recommended parameters:

  - Resolution Divisions: **The Higher The Better. This depends on your computer's performance.**
    - Generally, 300-500 will give you a nice visual effect.

  - Using Sence Gravity: ***Z*** direction = ***g***.

  - Enable **Adaptive Domain** (This will reduce bake time).
  - Enable **Dissolve**, set **Time** to 30, and enable **Slow**.
  - Enable **Noise**, set **Upres Factor** to 2, **Strength** to 0.75, **Scale** to 2 and **Time** to 0.1.
  - Modify **Fire**: Set **Reaction Speed** to 0.75, **Vorticity** to 1 and **Temperature Maximum** to 4.5, **Minimum** to 1.5.

Now, if you did everything correctly, click **Bake** and wait. A nearly realistic smoke will appear on your screen soon! (Tips: you can divide your Blender window into 3 areas - one for rendered viewport, one for **Shader Editor** and another for **Timeline**, and you can always use the **Camera View**!)

### Shader

Select a beautiful frame in the Timeline (everytime you bake, result will vary because this is a chaotic system). Now comes the most exciting part of this tutorial!

- Click the domain, and create these things in the shader editor:
  - **Flame**: Attribute (named **flame**).Fac - Math (**Multiply**) (another parameter **150-250**) - Strength.Emission (**color H: 0.082, S: 0.700, V: 1.000**) - Add Shader (mark as **AS1**) - Material Output (Volume).
  
  - **Density**: Attribute (named **density**).Fac - ColorRamp (named **DensityRamp**) - Math (**Add**) (another parameter **100**) - Density.Principled Volume (named **Smoke Principled Volume**) - **AS1** - Material Output (Volume).
  
  - **Color**: Musgrave Texture (- Vector Math (named **[EXP] Add Textures**)) - Fac.ColorRamp - Color.**Smoke Principled Volume** - **AS1** - Material Output (Volume).

    ![node](https://ftp.bmp.ovh/imgs/2021/02/655511c6d054d11c.png)
  *Example Node Configuration*
  
  Tips: If you don't know what to do, you can set as the picture implies.
  
### Render

Now comes the last part of the tutorial. Click *Render Proporties* tab and switch **Render Engine** to *Cycles*.

- Enable **Adaptive Sampling**.
- Enable **Denoising**. Use **NLM** render, and set **Start Sample** to 3.
- Set **Tiles Size** to **16 * 16** if you are using a **CPU** to render. If you are using a **GPU**, set **Tiles Size** to **256 * 256**.
- Now you are ready! Press **F12** to get your own smoke picture!

And below is a set of optional settings. These should be done before rendering.

- Click *Output Proporties* tab, set **Resolution** to your screen's resolution (or whatever else).

- Set **File Format** to a high-quality format e.g. PNG.

### Appendixes

If you do not want to do these by yourself, I also provide a [.blend file](129.211.80.104/smoke.blend).

Enjoy playing!

*FlifeX, MMXXXVIII*
