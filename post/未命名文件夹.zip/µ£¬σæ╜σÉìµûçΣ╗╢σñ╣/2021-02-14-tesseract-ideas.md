---
categories: tesseract
date: "2021-02-14T01:48:00Z"
title: Tesseract Ideas (2021)
---

### Tesseract Long-term Plan

*Latest Update: **2021/02/14***

> One should not stop at the world in front of one's eyes.

Tesseract is a chatting software that determines to have **the most secure chatting environment** in the world.

As for now, I have formulated the following objectives:

- Complete peer-to-peer chatting, with multi-person support;

- Encryption system;

- GUI (For technical reasons, we decided to use [Spectre.Console](https://github.com/spectresystems/spectre.console));

- Account system;

- and many unmentioned features!


Because this is really an exhausting work, I really need some help. If you would like to support us, you could contact us and join our [Trello page](https://trello.com/b/GIljVysf/tesseract), [GitHub repo](https://github.com/flifez/Tesseract), and <u>Discord server</u> (because my VPN is broken, I cannot get its link now).



