---
author: FlifeX
categories: cool_things
date: "2021-03-28T13:21:04Z"
title: Pendulum Simulation
---

### Introduction

Hey there! Today we are gonna simulate a pendulum with Mathematica. If you have done what I have written in [this article](/2021-02-26/tutorial_wolfram-with-jekyll.html), you can also try in Jupyter!

The tutorial also has some exercises for you. You can think them while reading!

### Principle and Method

By using ***Newton's* Second Law**, we are able to simulate a pendulum's motion. Here, I would like to introduce this nice principle first.

#### 	*Newton's* Second Law

An low-velocity object's *acceleration* is in proportion to the *force*, and in reverse proportion to its *mass*.
$$
\mathbf{F} = m\mathbf{a}
$$
To use it to simulate the pendulum, we need to write it as *differential form*:
$$
\begin{equation}
\left\{
\begin{aligned}
& m \cdot x_x''(t)=F_x(t) \\
& m \cdot x_y''(t)=F_y(t)
\end{aligned}
\right.,
\end{equation}
$$
where $x_x$ is the displacement in x-direction, $x_y$ is the displacement in y-direction, $t$ is elapsed time, $F_x$ is the force in x-direction, and, $F_y$ is the force in y-direction.

**Exercise 1.1** Why the second derivative of displacement is used here?

#### 	Method

We use ordinary differential equations (ODEs) to simulate.

Consider $\lambda$ the force, we have:
$$
\begin{equation}
\left\{
\begin{aligned}
& m \cdot x_x''(t)=\left(\frac{\lambda(t)}{l}\right)\cdot x(t) \\
& m \cdot x_y''(t)=\left(\frac{\lambda(t)}{l}\right)\cdot y(t)-m\cdot g
\end{aligned}
\right.,
\end{equation}
$$
Notice that the $x_x$ and $x_y$ here are simplifed expressions. The ODE has the same form compared to the equation mentioned in **Section 1.1**. With Mathematica, the equation can be represented as:

```mathematica
deqn = {m*x''[t] == (\[Lambda][t]/l) x[t], m*y''[t] == (\[Lambda][t]/l) y[t] -m*g}
```

and which is the equation to describe the movement of a pendulum.

### Preferences

#### Boundary Conditions

We do also need some preferences to make sure our simulation will work well. Firstly as is known to all, all ODEs need **boundary conditions** so that it can be solved correctly.
$$
x^2(t)+y^2(t)=l^2
$$

```mathematica
aeqn = {x[t]^2 + y[t]^2 == l^2}
```

This is our boundary condition. Because the length of pendulum is fixed during a very short time, the bob should travel along an arc. Think of a circle's standard equation, and you will get the point of the boundary condition. Actually, its essence is **Pythagorean Theorem**.

**Exercise 2.1** If boundary conditions here are ignored, what will happen?

#### Initial Conditions

**Initial conditions** are important if we want to solve the ODE numerically. To be simple, it is a set of data that determines what your things will do at the very beginning. And here, they are the *position* and *velocity* of the bob.

```mathematica
ic = {x[0] == Sqrt[3]/2, y[0] == -1/2, y'[0] == 0}
```

Without it, our pendulum will not work properly, so make sure you will define them before solving.

#### Parameters

Have you noticed that there are undefined variables (such as $g$) in the context? This is this section's topic, **parameters**.

Imagine a world without gravity. In such world, can you water your favorite plants? So, we must set a $g$ value. This is how parameters work: **they let everything in your simulation make sense**.

```mathematica
param = {g -> 9.81, m -> 1, l -> 1}
```

**Exercise 2.2** Try setting $l$ to a function with respect to time. What have you found?

#### Solving

Here comes the most exciting part. Actually here is nothing to say much (I assume you know how Mathematica or Wolfram Language works :) ).

```mathematica
soldp = First[
   NDSolve[{deqn, aeqn, ic} /. param, {x, y, \[Lambda]}, {t, 0, 40}, 
    Method ->
     {"IndexReduction" -> {"Pantelides", 
        "ConstraintMethod" -> "Projection"}}]];
```

### Animation

```mathematica
Animate[Graphics[{(**){PointSize[.025],
     {RGBColor[1, 0, 0], Point[{x[t], y[t]}]},
     {RGBColor[Abs[x'[t]]*Abs[y'[t]], 0, 0] /. soldp, 
      Line[{(**){0, 0}, {x[t], y[t]}}]}} /. soldp,
   {Gray, Dashed, 
    Line[Map[Function[Evaluate[{x[#], y[#]} /. soldp]], 
      Range[0, t, 0.01]]]}}], {t, 
  0, 60, .025}, AnimationRate -> 1, SaveDefinitions -> True]
```

By evaluating **pure functions** and customizing visual effect, you can create more incridible effects. Here, I used $x'(t)$ and $y'(t)$ to reflect the bob's velocity.

Now, you can export the animation. Have fun!

**Exercise 3.1** Export an animation. ~~and send it to me ;)~~

### Conclusions

Here is the end of the tutorial. If you have any questions, feel free to contact me!

**Final Exercise** Simulate a double pendulum. *Optional*: Do not ignore air resistance!

*FlifeX*

