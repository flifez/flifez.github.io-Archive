---
author: FlifeX
categories: calcraft
date: "2021-02-15T00:00:00Z"
time: 2021-02-15 17:07:05 +0800
title: The Origin of Calcraft (Part I)
---

### The Origin of Calcraft

What is Calcraft? Well, it is a compound (**Cal**culator + Mine**craft**). If we trace back to 2019, the story of Calcraft will show it to us completely.

In **Feb. 2019**, Gary a.k.a. MMXXXVIII and FlifeX started to build a calculator in Minecraft. They didn't think this as a difficult task at the very beginning, however this challenging task has never been accomplished. Surprisingly, this eventually become the origin of Calcraft - The greatest game server ever occurred in Syndicate's history.

Actually, I don't want to blow my own trumpet, however, unfortunately is true. Now (**Feb. 21**), Calcraft is still revitalizing its everlasting life-period of a game server yet, though two year have passed. The reason why Calcraft - the byproduct of a project that is never been done - has such strong vitality is even unknown to its creator, but he also believes Calcraft will go on in its unique way. Maybe it represents a spirit of willpower? I don't think so, but we can still gaze at its growing.

