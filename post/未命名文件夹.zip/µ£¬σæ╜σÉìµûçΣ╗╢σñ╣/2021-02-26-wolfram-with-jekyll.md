---
author: FlifeX
categories: tutorial
date: "2021-02-26T00:00:00Z"
time: 2021-02-26 10:57:00 +0800
title: How to use Wolfram Engine in Jupyter
---

- Estimated Reading Time: **10min**
<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="//music.163.com/outchain/player?type=2&id=574928897&auto=1&height=66"></iframe>

### Introduction

> I found that I have't updated this blog for nearly 10 days LOL... 

This tutorial will introduce a way to use Wolfram Engine in Jupyter (for better data-processing effeciency).

### Installing Wolfram Engine

1. You can download Wolfram Engine [here](https://www.wolfram.com/engine/) for free. Actually now the engine can be used in the attached executable WolframScript, but our goal is to implement the engine as a kernel of Jupyter.

2. Find a tutorial to download a `.paclet` file that adds feature to Wolfram Engine which supports Jupyter. I will not provide it here because I forgot how to install exactly. Just google keywords "Wolfram Engine + Jupyter" and you can get many full tutorials.

3. Check your Jupyter Notebook or Jupyter Lab. You should see "Wolfram Language" kernel now.

   If you test, you will find its syntax is just like what in Mathematica. However you cannot manipulate dynamic contents unless you have Mathematica, this is because Jupyter don't support it.

### Working with Wolfram and Python

Here I will just provide an easy example.

Python part: (If you install Jupyter using Anaconda the modules used below should be installed automatically)

```python
In[]:
import numpy as np
import sympy as sp

defsym = lambda sym: sp.Symbol(sym)
x = defsym('x')
testset = np.array([i/2 for i in range(1, 100)])
f = x**2

reslist = []
for num in testset:
  reslist.append(sp.integrate(f, (x, num, num + 1)))
  
print(reslist)
```

We copy `reslist` into another notebook that has a Wolfram kernel:

```mathematica
testlist = {reslist} (*We must ignore the []s here *)
ListLinePlot[testlist]
```

Here we will get a plot showing the result of integrals. This is much faster and easier than the module `matlibplot`.

*FlifeX*