---
author: FlifeX
categories: learning
date: "2021-04-03T20:37:00Z"
lastmod: 2021-05-01 12:37:21 +0800
title: Calculus Learning Note
---

- This document will be updated continuously.

### Introduction

**FlifeX Note**: As you can see, this is a record of my study of calculus or some insights. You can follow this document, and I will pin it in my blog later.

The document is not updated by chapters. It is more like a diary. If you want to browse this in chapter order, contact me plz.

(Note: Every comment by me in this doc will be labeled as "**FlifeX Note**".)

### 21/04/03

Proof of *Kepler's Second Law*.

**FlifeX Note**: Tool-book? You're thinkin' it right.

*Kepler's second law* says that the radius vector from the sun to a planet (the vector $\mathbf{r}$ in our model) sweeps out equal areas in equal times. To derive the law, we use Equation (4)
$$
\mathbf{v}=\dot{\mathbf{r}} = \frac{\mathrm{d}}{\mathrm{d}t}(r\mathbf{u}_r)=\dot{r}\mathbf{u}_r+r\dot{\mathbf{u}}_r=\dot{r}\mathbf{u}_r+r\dot{\theta}\mathbf{u}_\theta
$$
to evaluate the **cross product** $\mathbf{C}=\mathbf{r}\times\dot{\mathbf{r}}$ from Equation (14):
$$
\begin{aligned}
\mathbf{C}&=\mathbf{r}\times\dot{\mathbf{r}}=\mathbf{r}\times\mathbf{v}\\
&=\dot{r}\mathbf{u}_r\times(\dot{r}\mathbf{u}_r+r\dot{\theta}\mathbf{u}_\theta)\\
&=r\dot{r}\underbrace{(\mathbf{u}_r\times\mathbf{u}_r)}_\mathbf{0}+r(r\dot{\theta})\underbrace{(\mathbf{u}_r\times\mathbf{u}_\theta)}_\mathbf{k}\\
&=r(\dot{r\theta})\mathbf{k}.
\end{aligned}
\qquad(17)
$$
Setting $t$ equal to zero shows that
$$
\mathbf{C}=[r(r\dot{\theta})]_{t=0}\mathbf{k}=r_0v_0\mathbf{k}.
$$
Substituting this valve for $\mathbf{C}$ in Equation (17) gives
$$
r_0v_0\mathbf{k}=r^2\dot{\theta}\mathbf{k},\qquad\text{or}\qquad r^2\dot{\theta}=r_0v_0.
$$
This is where the area comes in. The area differential in **polar coordinates** is
$$
\mathrm{d}A=\frac{1}{2}r^2\mathrm{d}\theta.
$$
Accordingly, $\mathrm{d}A/\mathrm{d}t$ has the constant value
$$
\frac{\mathrm{d}A}{\mathrm{d}t}=\frac{1}{2}r^2\dot{\theta}=\frac{1}{2}r_0v_0.
$$
So $\mathrm{d}A/\mathrm{d}t$ is constant, giving *Kepler's second law*.

### Appendix: A Brief Table of Integrals

$$
\begin{aligned}
&1.\int u\mathrm{d}v=uv-\int v\mathrm{d}u\\
&3.\int \cos u \mathrm{d}u = \sin u + C\\
&5.\int (ax+b)^n\mathrm{d}x = \frac{(ax+b)^{n+1}}{a(n+1)}+C,n\neq-1\\
&7.\\
&9.\\
\end{aligned}
\qquad
\begin{aligned}
&2.\int a^u\mathrm{d}u=\frac{a^u}{\ln a} + C,a \neq 1, a > 0\\
&4.\int \sin u \mathrm{d}u=-\cos u + C\\
&6.\\
&8.\\
&10.\\
\end{aligned}
$$

