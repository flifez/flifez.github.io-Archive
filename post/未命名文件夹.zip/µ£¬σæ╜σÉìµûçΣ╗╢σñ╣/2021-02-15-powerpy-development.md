---
author: FlifeX
categories: coding
date: "2021-02-15T19:49:00Z"
title: PowerPy Development Log
---

### Introduction

**PowerPy** is a Python Shell aims to have the similar functions to `bash`, `zsh` or other Linux Shells.

Up to now, PowerPy has a incompleted standalone account management system, and its Prompt is still using `eval` function.

### Typical Functions

In the development process of PowerPy, I also encountered some disgusting problems. Here are some typical functions.

1. ```python
   def loop(self, username):
       PROMPT_PREFIX = username + ' $ '
       while True:
           issue_command = 'os.system(\'%s\')' % input(PROMPT_PREFIX)
           eval(issue_command)
   ```

   Yes, you may think it as an easy thing. However, it doesn't seemed to be very easy for me, because I don't know how to evaluate shell commands in Python correctly. At last, I had no choice but using `eval()` function of Python.

