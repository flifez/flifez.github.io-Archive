---
layout: post
title: "Tesseract 想法 (2021)"
date:  2021-02-14 01:48:00 +0800
categories: tesseract
---

### Tesseract 长期计划

最近更新：**2021/02/14**

> 一个人不应止步于眼前的世界。

Tesseract 是一个致力于拥有**世界上最安全的聊天环境**的聊天软件。

目前，我拟定了如下目标：

- 完全的 P2P 多人对话；

- 加密系统；

- GUI（由于技术原因，我们决定使用 [Spectre.Console](https://github.com/spectresystems/spectre.console)）；

- 账户系统；

- 以及许多未提到的功能！


因为这东西实在是太累人了，我真的需要帮忙。如果你有意帮助我们，你可以联系我们并加入我们的 [Trello 主页](https://trello.com/b/GIljVysf/tesseract)，[GitHub 仓库](https://github.com/flifez/Tesseract)，和 <u>Discord 服务器</u> (因为我的 VPN 没法用了，现在我拿不到它的链接）。



