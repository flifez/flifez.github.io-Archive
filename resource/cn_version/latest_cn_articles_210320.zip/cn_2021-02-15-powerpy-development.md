---
layout: 	post
title: 		"PowerPy 开发日志"
author: 	FlifeX
date: 		2021-02-15 19:49:00 +0800
categories: coding
---

### 引言

**PowerPy** 是一个用 Python 写的 Shell，致力于达到与`bash`，`zsh`等 Linux Shell 相似的功能。

目前，PowerPy 有一个不完整的账户管理系统，它的提示符甚至还在用 `eval` 函数。

### 典型函数

PowerPy 的开发过程中，我也遇到过许多恶心的问题。下面是一些典型的函数。

1. ```python
   def loop(self, username):
       PROMPT_PREFIX = username + ' $ '
       while True:
           issue_command = 'os.system(\'%s\')' % input(PROMPT_PREFIX)
           eval(issue_command)
   ```

   是的，你也许会认为：”就这？“，然而对我来说并不那么容易，因为我不知道如何用 Python 正确执行 Shell 命令。最后，我还是不得不用 Python 的 `eval()` 函数。

