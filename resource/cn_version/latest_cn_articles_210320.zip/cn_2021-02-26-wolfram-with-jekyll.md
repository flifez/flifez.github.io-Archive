---
layout: 	post
title: 		How to use Wolfram Engine in Jupyter
author: 	FlifeX
time: 		2021-02-26 10:57:00 +0800
categories: tutorial
---

- 预计阅读时间：**10分钟**

<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 
src="//music.163.com/outchain/player?type=2&id=574928897&auto=1&height=66"></iframe>

### 引言

> 我发现我已经十天没更新这玩意了……

此教程将介绍一种在 Jupyter 中使用 Wolfram Engine 的方法，以便获得更高的数据处理效率。

### 安装 Wolfram Engine

1. 你可以在[这里](https://www.wolfram.com/engine/)免费下载 Wolfram Engine。实际上它也能在附带的 WolframScript 中运行，不过我们的目标是将它植入为 Jupyter 的一个内核。

2. 找一个教程，它应该会让你下载一个`.paclet`文件来向 Wolfram Engine 添加支持 Jupyter 的特性。我无法提供这个文件，因为我忘了具体过程。你只要上网搜索 "Wolfram Engine + Jupyter" 就能看到许多完整教程。

3. 打开 Jupyter Lab 或 Jupyter Notebook。你现在应该能选择 "Wolfram Language" 内核了。

### 联合 Wolfram 语言和 Python

举个例子。

Python 部分：（如果你使用 Anaconda 安装 Jupyter，所使用的包应该会自动安装）

```python
In[]:
import numpy as np
import sympy as sp

defsym = lambda sym: sp.Symbol(sym)
x = defsym('x')
testset = np.array([i/2 for i in range(1, 100)])
f = x**2

reslist = []
for num in testset:
  reslist.append(sp.integrate(f, (x, num, num + 1)))
  
print(reslist)
```

把 `reslist` 复制进另一个有 Wolfram 内核的 Notebook：

```mathematica
testlist = {reslist} (*We must ignore the []s here *)
ListLinePlot[testlist]
```

我们会得到一个显示了积分结果的图。这比 `matplotlib` 包不知道快到哪里去了。

*FlifeX*