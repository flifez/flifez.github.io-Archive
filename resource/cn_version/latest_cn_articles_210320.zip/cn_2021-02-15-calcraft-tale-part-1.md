---
layout: 	post
title: 		"Calcraft 的起源 (第一节)"
time: 		2021-02-15 17:07:05 +0800
author: 	FlifeX
categories: calcraft
---

### Calcraft 的起源

什么是 Calcraft？它是个合成词 （**Cal**culator + Mine**craft**）。追溯 2019，Calcraft 的故事便会完全向我们展现。

在 **2019 年 2 月**, Gary（MMXXXVIII）和 FlifeX 开始在 Minecraft 里造计算器。最开始他们并没把这东西的难度当回事，但这个困难的任务从未被完成过。出人意料，这最终成为了 Calcraft 的起源 —— Syndicate 历史上曾出现过的最伟大的游戏服务器。

实际上，我不想自吹自擂。但不幸的是，这确实是实话。现在（**2021 年 2 月**），尽管两年已经过去，Calcraft 仍在展现它的无穷生命力。Calcraft —— 一个从未被完成的项目的副产物 —— 之所以拥有如此强大的生命力的缘由，甚至连它的创造者也不知道，但他也相信 Calcraft 会以它独特的方式走下去。也许它代表了一种意志力？我并不认为，但我们仍可以凝视它一步一步的成长下去。

